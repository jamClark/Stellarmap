#include <lib.h>
#include <damage_types.h>
#include <vendor_types.h>
#include "../include.h"

///Stellarmap Generator Metacode, do not modify
///StellarmapCode:Inherit

static void create()
	{
	::create();
	}

void init()
	{
	::init();
	}

