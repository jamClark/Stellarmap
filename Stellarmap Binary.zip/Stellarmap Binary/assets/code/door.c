#include <lib.h>
#include "../include.h"

inherit LIB_DOOR;

static void create()
	{
    ::create();
    
	}
void init(){
    ::init();
}