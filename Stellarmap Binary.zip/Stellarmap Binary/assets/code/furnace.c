#include <lib.h>
#include "../include.h"

inherit LIB_FURNACE;

void create() {
    furnace::create();
}
void init(){
    ::init();
}
