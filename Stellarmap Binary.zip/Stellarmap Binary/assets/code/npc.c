#include <lib.h>
#include "../include.h"

///Stellarmap Generator Metacode, do not modify
///StellarmapCode:Inherit


static void create() {
    ::create();
	SetRace("human");
    SetClass("vitalnpc");
    SetLevel(10);
    }

void init(){
    ::init();
}
